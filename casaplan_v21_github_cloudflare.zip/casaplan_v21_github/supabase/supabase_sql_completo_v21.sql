-- CasaPlan v18 - SQL COMPLETO para Supabase
-- Pega TODO este archivo en Supabase > SQL Editor > Run.
-- Sirve tanto para instalación nueva como para actualizar una base existente. Incluye tareas compartidas por varias personas y registro de tareas realizadas por una persona distinta a la asignada y tareas programadas en varios días.

create extension if not exists pgcrypto;

-- =====================================================
-- 1) TABLAS PRINCIPALES
-- =====================================================

create table if not exists public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'CasaPlan Familia',
  invite_code text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  name text not null,
  color text not null default '#2563eb',
  away boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.rooms (
  id text not null,
  family_id uuid not null references public.families(id) on delete cascade,
  name text not null,
  icon text not null default '🏠',
  is_default boolean not null default false,
  sort_order integer not null default 100,
  created_at timestamptz not null default now(),
  primary key (family_id, id)
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  description text,
  member_id uuid references public.members(id) on delete set null,
  due_date date not null default current_date,
  start_date date not null default current_date,
  end_date date not null default current_date,
  repeat text not null default 'none',
  points integer not null default 1,
  status text not null default 'pending',
  completed_at timestamptz,
  completed_by_member_id uuid references public.members(id) on delete set null,
  completed_by_override boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.task_assignments (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  status text not null default 'pending',
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (task_id, member_id)
);

create table if not exists public.shopping_items (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  bought boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.task_photos (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  storage_path text not null unique,
  created_at timestamptz not null default now()
);

-- =====================================================
-- 2) COMPATIBILIDAD PARA BASES ANTIGUAS
-- =====================================================

alter table public.families add column if not exists name text not null default 'CasaPlan Familia';
alter table public.families add column if not exists invite_code text;
alter table public.families add column if not exists created_at timestamptz not null default now();

alter table public.members add column if not exists family_id uuid references public.families(id) on delete cascade;
alter table public.members add column if not exists name text;
alter table public.members add column if not exists color text not null default '#2563eb';
alter table public.members add column if not exists away boolean not null default false;
alter table public.members add column if not exists created_at timestamptz not null default now();

alter table public.tasks add column if not exists family_id uuid references public.families(id) on delete cascade;
alter table public.tasks add column if not exists title text;
alter table public.tasks add column if not exists description text;
alter table public.tasks add column if not exists member_id uuid references public.members(id) on delete set null;
alter table public.tasks add column if not exists due_date date not null default current_date;
alter table public.tasks add column if not exists start_date date not null default current_date;
alter table public.tasks add column if not exists end_date date not null default current_date;
alter table public.tasks add column if not exists repeat text not null default 'none';
alter table public.tasks add column if not exists points integer not null default 1;
alter table public.tasks add column if not exists status text not null default 'pending';
alter table public.tasks add column if not exists completed_at timestamptz;
alter table public.tasks add column if not exists completed_by_member_id uuid references public.members(id) on delete set null;
alter table public.tasks add column if not exists completed_by_override boolean not null default false;
alter table public.tasks add column if not exists created_at timestamptz not null default now();

alter table public.task_assignments add column if not exists family_id uuid references public.families(id) on delete cascade;
alter table public.task_assignments add column if not exists task_id uuid references public.tasks(id) on delete cascade;
alter table public.task_assignments add column if not exists member_id uuid references public.members(id) on delete cascade;
alter table public.task_assignments add column if not exists status text not null default 'pending';
alter table public.task_assignments add column if not exists completed_at timestamptz;
alter table public.task_assignments add column if not exists created_at timestamptz not null default now();

alter table public.shopping_items add column if not exists family_id uuid references public.families(id) on delete cascade;
alter table public.shopping_items add column if not exists title text;
alter table public.shopping_items add column if not exists bought boolean not null default false;
alter table public.shopping_items add column if not exists created_at timestamptz not null default now();

-- Normaliza valores para que no fallen futuras validaciones de la app.
-- Rellena fechas de programación en bases anteriores.
update public.tasks set start_date = coalesce(start_date, due_date, current_date) where start_date is null;
update public.tasks set end_date = coalesce(end_date, due_date, start_date, current_date) where end_date is null;
update public.tasks set due_date = coalesce(due_date, end_date, start_date, current_date) where due_date is null;
update public.tasks set repeat = 'none' where repeat is null or repeat not in ('none','daily','weekly','biweekly','monthly');
update public.tasks set status = 'pending' where status is null or status not in ('pending','done');
update public.tasks set points = 1 where points is null or points < 1;
update public.tasks set completed_by_override = false where completed_by_override is null;
update public.tasks set completed_by_member_id = member_id where status = 'done' and completed_by_member_id is null and member_id is not null and coalesce(completed_by_override,false) = false;
update public.task_assignments set status = 'pending' where status is null or status not in ('pending','done');

-- =====================================================
-- 3) ÍNDICES
-- =====================================================

create unique index if not exists idx_families_invite_code_unique on public.families(invite_code);
create index if not exists idx_members_family_id on public.members(family_id);
create index if not exists idx_rooms_family_id on public.rooms(family_id);
create index if not exists idx_tasks_family_id on public.tasks(family_id);
create index if not exists idx_tasks_due_date on public.tasks(due_date);
create index if not exists idx_tasks_start_date on public.tasks(start_date);
create index if not exists idx_tasks_end_date on public.tasks(end_date);
create index if not exists idx_tasks_member_id on public.tasks(member_id);
create index if not exists idx_tasks_completed_by_member_id on public.tasks(completed_by_member_id);
create index if not exists idx_task_assignments_family_id on public.task_assignments(family_id);
create index if not exists idx_task_assignments_task_id on public.task_assignments(task_id);
create index if not exists idx_task_assignments_member_id on public.task_assignments(member_id);
create index if not exists idx_shopping_items_family_id on public.shopping_items(family_id);
create index if not exists idx_task_photos_family_id on public.task_photos(family_id);
create index if not exists idx_task_photos_task_id on public.task_photos(task_id);

-- =====================================================
-- 4) HABITACIONES BASE PARA FAMILIAS YA EXISTENTES
-- =====================================================

insert into public.rooms (family_id, id, name, icon, is_default, sort_order)
select f.id, r.id, r.name, r.icon, true, r.sort_order
from public.families f
cross join (values
  ('cocina', 'Cocina', '🍳', 0),
  ('bano', 'Baño', '🚿', 1),
  ('salon', 'Salón', '🛋️', 2),
  ('dormitorio', 'Dormitorio', '🛏️', 3),
  ('garaje', 'Garaje', '🧰', 4),
  ('exterior', 'Exterior', '🌿', 5)
) as r(id, name, icon, sort_order)
on conflict (family_id, id) do nothing;

-- =====================================================
-- 5) MIGRACIÓN: tareas antiguas con una persona asignada
-- =====================================================

insert into public.task_assignments (family_id, task_id, member_id, status, completed_at)
select t.family_id, t.id, t.member_id, t.status, t.completed_at
from public.tasks t
where t.member_id is not null
on conflict (task_id, member_id) do nothing;

-- =====================================================
-- 6) STORAGE PARA FOTOS
-- =====================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'task-photos',
  'task-photos',
  true,
  5242880,
  array['image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- =====================================================
-- 7) RLS + PERMISOS
-- La app actual usa código familiar, no login. Por eso se permite anon/auth.
-- =====================================================

alter table public.families enable row level security;
alter table public.members enable row level security;
alter table public.rooms enable row level security;
alter table public.tasks enable row level security;
alter table public.task_assignments enable row level security;
alter table public.shopping_items enable row level security;
alter table public.task_photos enable row level security;

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.families to anon, authenticated;
grant select, insert, update, delete on public.members to anon, authenticated;
grant select, insert, update, delete on public.rooms to anon, authenticated;
grant select, insert, update, delete on public.tasks to anon, authenticated;
grant select, insert, update, delete on public.task_assignments to anon, authenticated;
grant select, insert, update, delete on public.shopping_items to anon, authenticated;
grant select, insert, update, delete on public.task_photos to anon, authenticated;

drop policy if exists "casaplan families select" on public.families;
drop policy if exists "casaplan families insert" on public.families;
drop policy if exists "casaplan families update" on public.families;
drop policy if exists "casaplan families delete" on public.families;
drop policy if exists "casaplan members all" on public.members;
drop policy if exists "casaplan rooms all" on public.rooms;
drop policy if exists "casaplan tasks all" on public.tasks;
drop policy if exists "casaplan task assignments all" on public.task_assignments;
drop policy if exists "casaplan shopping all" on public.shopping_items;
drop policy if exists "casaplan task photos all" on public.task_photos;

create policy "casaplan families select" on public.families for select to anon, authenticated using (true);
create policy "casaplan families insert" on public.families for insert to anon, authenticated with check (true);
create policy "casaplan families update" on public.families for update to anon, authenticated using (true) with check (true);
create policy "casaplan families delete" on public.families for delete to anon, authenticated using (true);
create policy "casaplan members all" on public.members for all to anon, authenticated using (true) with check (true);
create policy "casaplan rooms all" on public.rooms for all to anon, authenticated using (true) with check (true);
create policy "casaplan tasks all" on public.tasks for all to anon, authenticated using (true) with check (true);
create policy "casaplan task assignments all" on public.task_assignments for all to anon, authenticated using (true) with check (true);
create policy "casaplan shopping all" on public.shopping_items for all to anon, authenticated using (true) with check (true);
create policy "casaplan task photos all" on public.task_photos for all to anon, authenticated using (true) with check (true);

-- Storage policies.
drop policy if exists "casaplan task photos storage select" on storage.objects;
drop policy if exists "casaplan task photos storage insert" on storage.objects;
drop policy if exists "casaplan task photos storage update" on storage.objects;
drop policy if exists "casaplan task photos storage delete" on storage.objects;

create policy "casaplan task photos storage select" on storage.objects
for select to anon, authenticated using (bucket_id = 'task-photos');

create policy "casaplan task photos storage insert" on storage.objects
for insert to anon, authenticated with check (bucket_id = 'task-photos');

create policy "casaplan task photos storage update" on storage.objects
for update to anon, authenticated using (bucket_id = 'task-photos') with check (bucket_id = 'task-photos');

create policy "casaplan task photos storage delete" on storage.objects
for delete to anon, authenticated using (bucket_id = 'task-photos');

-- =====================================================
-- 8) REALTIME
-- =====================================================

alter table public.families replica identity full;
alter table public.members replica identity full;
alter table public.rooms replica identity full;
alter table public.tasks replica identity full;
alter table public.task_assignments replica identity full;
alter table public.shopping_items replica identity full;
alter table public.task_photos replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'families') then
      alter publication supabase_realtime add table public.families;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'members') then
      alter publication supabase_realtime add table public.members;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'rooms') then
      alter publication supabase_realtime add table public.rooms;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'tasks') then
      alter publication supabase_realtime add table public.tasks;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'task_assignments') then
      alter publication supabase_realtime add table public.task_assignments;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'shopping_items') then
      alter publication supabase_realtime add table public.shopping_items;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'task_photos') then
      alter publication supabase_realtime add table public.task_photos;
    end if;
  end if;
end $$;

-- Fuerza a PostgREST/Supabase a recargar la caché de esquema.
notify pgrst, 'reload schema';

-- =====================================================
-- 9) COMPROBACIÓN FINAL
-- Si esto devuelve todas las tablas con "ok", el SQL está aplicado.
-- =====================================================

select
  'families' as tabla, case when to_regclass('public.families') is not null then 'ok' else 'falta' end as estado
union all select 'members', case when to_regclass('public.members') is not null then 'ok' else 'falta' end
union all select 'rooms', case when to_regclass('public.rooms') is not null then 'ok' else 'falta' end
union all select 'tasks', case when to_regclass('public.tasks') is not null then 'ok' else 'falta' end
union all select 'task_assignments', case when to_regclass('public.task_assignments') is not null then 'ok' else 'falta' end
union all select 'shopping_items', case when to_regclass('public.shopping_items') is not null then 'ok' else 'falta' end
union all select 'task_photos', case when to_regclass('public.task_photos') is not null then 'ok' else 'falta' end;
