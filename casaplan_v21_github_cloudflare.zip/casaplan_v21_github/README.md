# CasaPlan

App web/PWA para organizar tareas de casa, miembros, habitaciones, fotos y sincronización con Supabase.

## Despliegue recomendado

### Cloudflare Pages

- Framework preset: None
- Build command: dejar vacío
- Output directory: `/`

### Archivos principales

- `index.html`: aplicación principal
- `manifest.webmanifest`: configuración PWA
- `version.json`: versión publicada para actualización automática
- `_headers`: cabeceras para evitar caché antigua
- `assets/`: iconos y logo
- `supabase/`: SQL completo y migraciones

## Supabase

Si ya tienes CasaPlan funcionando, no ejecutes SQL sin revisar antes si lo necesitas.

Para instalación nueva, usa:

`supabase/supabase_sql_completo_v21.sql`

Para actualizar desde una versión previa, usa la migración correspondiente si existe.

## Notas

Esta versión está preparada para subirse a GitHub y conectarse a Cloudflare Pages.
