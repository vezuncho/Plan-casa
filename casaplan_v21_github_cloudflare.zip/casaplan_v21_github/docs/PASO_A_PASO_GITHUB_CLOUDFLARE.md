# Paso a paso: GitHub + Cloudflare Pages

## 1. Crear repositorio en GitHub

1. Entra en GitHub.
2. Pulsa New repository.
3. Nombre: `casaplan`.
4. Puede ser privado.
5. No hace falta añadir README porque este ZIP ya lo incluye.

## 2. Subir archivos

1. Entra en el repositorio.
2. Pulsa Add file > Upload files.
3. Arrastra todos los archivos y carpetas de este ZIP.
4. Pulsa Commit changes.

## 3. Conectar Cloudflare Pages

1. Entra en Cloudflare.
2. Ve a Workers & Pages.
3. Pulsa Create > Pages.
4. Conecta con GitHub.
5. Elige el repositorio `casaplan`.
6. Configuración:
   - Framework preset: None
   - Build command: vacío
   - Output directory: `/`
7. Pulsa Deploy.

## 4. Probar

1. Abre la URL que te da Cloudflare.
2. Comprueba que carga CasaPlan.
3. Mira en Ajustes la versión.
4. Prueba desde el móvil principal.
5. Prueba desde el móvil de tu mujer.

## 5. Instalar en móvil

Desde Chrome:

1. Abre la URL de Cloudflare.
2. Menú de tres puntos.
3. Añadir a pantalla de inicio.
